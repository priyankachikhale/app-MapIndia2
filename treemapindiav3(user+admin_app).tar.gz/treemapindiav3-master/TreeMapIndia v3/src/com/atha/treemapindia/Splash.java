package com.atha.treemapindia;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.atha.csvexport.CSVexport;
import com.atha.treemapindia.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.widget.Toast;

/**
 * This is the initial splash screen
 * */

public class Splash extends Activity
{

	private static final int	SPLASH_DISPLAY_TIME	= 2000; /* 2 seconds */
	String dwnload_file_path = "http://10.15.36.57//MapIndia.db";
	int totalSize=0;
	int downloadedSize=0;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);

		/*
		 * Create a new handler with which to start the main activity and close this splash activity
		 * after SPLASH_DISPLAY_TIME has elapsed.
		 */
		new Handler().postDelayed(new Runnable() {
			@Override
			public void run()
			{

				 /*Thread t = new Thread(new Runnable() {
						
						@Override
						public void run() {

							downloadFile();
						}
					});
	               
	                 t.start();
*/
				/* Create an intent that will start the main activity. */
				Intent mainIntent = new Intent(Splash.this, LoginActivity.class);

				Splash.this.startActivity(mainIntent);

				/* Finish splash activity so user cant go back to it. */
				Splash.this.finish();

				/*
				 * Apply our splash exit (fade out) and main entry (fade in) animation transitions.
				 */
				overridePendingTransition(R.anim.mainfadein, R.anim.splashfadeout);
			}
		}, SPLASH_DISPLAY_TIME);
	}
	void downloadFile(){
        
        try {
            URL url = new URL(dwnload_file_path);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
 
            urlConnection.setRequestMethod("GET");
            urlConnection.setDoOutput(true);
 
            //connect 
            //File root = android.os.Environment.getExternalStorageDirectory();
            //File dir = new File(root.getAbsolutePath() + "/myclock/databases");
            //set the path where we want to <span class="IL_AD" id="IL_AD3">save the</span> file           
            //File SDCardRoot = Environment.getExternalStorageDirectory();
            //File Root =Environment.getExternalStorageDirectory();
            //create a new file, to save the downloaded file
           // File file = new File(SDCardRoot.getAbsolutePath() + "/com.atha.treemapindia/databases");
            File file = new File("/data/data/com.atha.treemapindia/databases/MapIndia.db");
            FileOutputStream fileOutput = new FileOutputStream(file);
 
            //Stream used for reading the data from the internet
            InputStream inputStream = urlConnection.getInputStream();
 
            //this is the total size of the file which we are downloading
            totalSize = urlConnection.getContentLength();
 
           /* runOnUiThread(new Runnable() {
                public void run() {
                    pb.setMax(totalSize);
                }              
            });*/
             
            //create a buffer...
            byte[] buffer = new byte[1024];
            int bufferLength = 0;
 
            while ( (bufferLength = inputStream.read(buffer)) > 0 ) {
                fileOutput.write(buffer, 0, bufferLength);
                downloadedSize += bufferLength;
                // update the progressbar //
                /*runOnUiThread(new Runnable() {
                    public void run() {
                        pb.setProgress(downloadedSize);
                        float per = ((float)downloadedSize/totalSize) * 100;
                        cur_val.setText("Downloaded " + downloadedSize + "KB / " + totalSize + "KB (" + (int)per + "%)" );
                    }
                });*/
            }
            //close the output stream when complete //
            fileOutput.close();
            runOnUiThread(new Runnable() {
                public void run() {
                    // pb.dismiss(); // if you want close it..
                }
            });        
         
        } catch (final MalformedURLException e) {
            showError("Error : MalformedURLException " + e);       
            e.printStackTrace();
        } catch (final IOException e) {
            showError("Error : IOException " + e);         
            e.printStackTrace();
        }
        catch (final Exception e) {
            //showError("Error : Please <span class="IL_AD" id="IL_AD4">check your</span> internet connection " + e);
        	showError("Error : Please check your internet connection " + e);
        }      
    }
   
   void showError(final String err){
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(Splash.this, err, Toast.LENGTH_LONG).show();
            }
        });
    }
}