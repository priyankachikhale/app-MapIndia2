package com.atha.treemapindia;

import java.io.Serializable;

public class Attribute implements Serializable{
	private String name;	
	private String type;
	private String value;
	private String showcase;
	private String range;
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

	
	
	public String getRange() {
		return range;
	}
	public void setRange(String range) {
		this.range = range;
	}
	public String getShowcase() {
		return showcase;
	}
	public void setShowcase(String showcase) {
		this.showcase = showcase;
	}
	public Attribute() {
	
	}
	public Attribute(String name, String type) {
		this.name = name;
		this.type = type;
	}
	
	public String getName() {
	return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
