package com.atha.treemapindia;



import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.AlertDialog.Builder;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Point;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.os.RemoteException;
import android.provider.Settings;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import com.atha.csvexport.CSVexport;
import com.atha.gps.MyLocationListener;
import com.atha.gps.MyNetworkLocationListener;
import com.google.android.apps.mytracks.content.MyTracksProviderUtils;
import com.google.android.apps.mytracks.content.Track;
import com.google.android.apps.mytracks.services.ITrackRecordingService;
import com.google.android.apps.mytracks.stats.TripStatistics;

/**
 * This activity shows the initial page
 * */

public class Layer_Selection_Show extends Activity
{

	
	TextView	                   ftv, htv, d_id;
	
	
	
	Button	                       badd_tree, cancel, exdata;
	EditText	                   etname, etpdesc, etsuno, ethno, etarea;
	Spinner	                       etpoly, etward;
	String	                       prabhagNo	     = "";
	String	                       clusterNo	     = "";

	Spinner	                       spptype;
	String	                       oname	         = null, pd = null,
	        sn = null, hn = null, area = null, androidId;
	
	

	private SQLiteDatabase	       db;

	Track	                       tr	             = null;
	int	                           st	             = 0;
	// utils to access the MyTracks content provider
	private MyTracksProviderUtils	myTracksProviderUtils;

	// MyTracks service
	private ITrackRecordingService	myTracksService;

	// intent to access the MyTracks service
	private Intent	               intent;

	private int	                   surveyorId;
	private boolean	               serviceConnected	 = false;

	LocationManager	               mlocManager	     = null;
	LocationListener	           mlocListener;
	LocationListener	           mnetworklocListener;

	
	// connection to the MyTracks service
			private ServiceConnection	   serviceConnection	= new ServiceConnection() {
				                                                 @Override
				                                                 public void onServiceConnected(ComponentName className, IBinder service)
				                                                 {
					                                                 myTracksService = ITrackRecordingService.Stub.asInterface(service);
					                                                 serviceConnected = true;
				                                                 }

				                                                 @Override
				                                                 public void onServiceDisconnected(ComponentName className)
				                                                 {
					                                                 myTracksService = null;
					                                                 System.out.println("mytracks service disconnected");
				                                                 }
			                                                 };

	private boolean	               prabhagSelected	 = true;
	private boolean	               clusterSelected	 = false;
	private boolean	               propertySelected	 = false;
	private DBHelper dbHelper;
	
	 
	  //for dynamic layer addition 
	 
	private List<EditText> allEds = new ArrayList<EditText>();
	private static ArrayList<String> layerNames= new ArrayList<String>();
	public static ArrayList<String> getlayerNames() {
		return layerNames;
	}
	public static void setlayerNames(ArrayList<Attribute> layerList) {
		Layer_Selection_Show.layerNames = layerNames;
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layer_select);

		//code to add layers dynamically
		TableLayout tl = (TableLayout) findViewById(R.id.layoutButtons);
		LayoutParams lp = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		
		dbHelper= new DBHelper(this);
    	db=dbHelper.openDatabase();
    	int size=layerNames.size();
    	for(String attr : layerNames)
    	{
    		if(size==0)
    			break;
    		layerNames.remove(size-1);
    		size--;
    	}
		//Cursor  cursor = db.rawQuery("select * from " + ("LAYER_").concat(dbHelper.getUserDomain(LoginActivity.getLogin(),db)),null);
    	String a;
    	a=LoginActivity.getDomain();
//    	Cursor  cursor = db.rawQuery("select * from " + ("LAYER_").concat(LoginActivity.getDomain()),null);
    	Cursor  cursor = db.rawQuery("select * from layer_school",null);
    	
    	System.out.println("hi");
		if (cursor.moveToFirst()) {

            while (cursor.isAfterLast() == false) {
                String name = cursor.getString(cursor
                        .getColumnIndex("LAYER_NAME"));

                layerNames.add(name);
                cursor.moveToNext();
            }
        }
		else
			System.out.println("hi");
		db.close();
		Iterator<String> it = layerNames.iterator();
		while(it.hasNext()){
			TextView textview =new TextView(this); 
			textview.setText(it.next().toString());
			
			EditText editText =new EditText(this);
			TableRow tr = new TableRow(this);
			tr.setLayoutParams(lp);
			tr.addView(textview);
			tr.addView(editText);
			tl.addView(tr, new TableLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
		}
		


		
		mlocManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		mlocListener = new MyLocationListener(Layer_Selection_Show.this);
		mnetworklocListener = new MyNetworkLocationListener(Layer_Selection_Show.this);
		if (mlocManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
		    mlocManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, mlocListener);
		}
		mlocManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, mlocListener);
		//mlocManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1, 0, mlocListener);
		//mlocManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1, 0, mnetworklocListener);

		androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
		d_id = (TextView) findViewById(R.id.devid);
		//d_id.setText("Device ID   :  " + androidId);
		myTracksProviderUtils = MyTracksProviderUtils.Factory.get(this);
		
		// for creating a folder
		String newFolder1 = "/" + androidId;
		String extStorageDirectory1 = Environment.getExternalStorageDirectory().toString();
		File myNewFolder1 = new File(extStorageDirectory1 + newFolder1);
		myNewFolder1.mkdir();
		//String newFolder = "/" + androidId + "/EMAGPS";
		//String extStorageDirectory = Environment.getExternalStorageDirectory().toString();
		//File myNewFolder = new File(extStorageDirectory + newFolder);
		//myNewFolder.mkdir();

		st = getIntent().getIntExtra("track", 0);
		
		intent = new Intent();
		ComponentName componentName = new ComponentName(getString(R.string.mytracks_service_package), getString(R.string.mytracks_service_class));
		intent.setComponent(componentName);
		
		// Start tracking
		Button startRecordingButton = (Button) findViewById(R.id.stt);
		startRecordingButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v)
			{
				
				
			

				
				if (myTracksService != null)
				{
					try
					{
						Log.i("mytracksservice", "obj " + (myTracksService == null ? "null" : myTracksService.toString()));
						Log.i("Service Connection", "Service conncted: " + serviceConnected);
						long trackId = myTracksService.startNewTrack();
						
						Log.i("myTracksService", "startnewtrack: " + trackId);
						
						tr = myTracksProviderUtils.getLastTrack();
						
						Log.i("is track", "track : " + (tr == null ? "null" : tr.toString()));
						st = 1;
					}
					catch (RemoteException e)
					{
						e.printStackTrace();
					}
				}
				v.setEnabled(false);
			}
		});

		dbHelper = new DBHelper(this);

		Button badd_tree = (Button) findViewById(R.id.add_tree);
		
		Button exdata = (Button) findViewById(R.id.exda);
		cancel = (Button) findViewById(R.id.cancel);
	


		


		exdata.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v)
			{

				final ProgressDialog myPd_ring = ProgressDialog.show(Layer_Selection_Show.this, "Please wait", "Data is Exporting...", true);
				myPd_ring.setCancelable(true);
				new Thread(new Runnable() {
					@Override
					public void run()
					{
						try
						{
							try
							{
								Log.i("data dump", "begin");
								dbHelper.openDatabase();
								dbHelper.databaseDump(androidId);
								Log.i("data dump", "end");
							}
							catch (IOException e)
							{
								e.printStackTrace();
							}
							// Thread.sleep(5000);
						}
						catch (Exception e)
						{
							e.printStackTrace();
						}
						myPd_ring.dismiss();
					}
				}).start();
			}
		});

		
		badd_tree.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v)
			{
				Location loc = myTracksProviderUtils.getLastValidTrackPoint();
				st=1;
				if (st == 1)
				{
					
					
						dbHelper.openDatabase();

						
						Intent in = new Intent(Layer_Selection_Show.this, Screen_Selection.class);
				
				
						startActivity(in);
						finish();
				}
					
				
				else
				{
					AlertDialog.Builder alertDialogBuilder1 = new AlertDialog.Builder(Layer_Selection_Show.this);
					alertDialogBuilder1.setMessage("Your tracking is Not started \n You have to start Tracking first with pressing button start tracking???").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id)
						{
							// if this button is clicked, close
							// current activity
							dialog.cancel();

						}
					}).show();
				}
			}
		});

		
		
		
		
		cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v)
			{
				AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(Layer_Selection_Show.this);
				alertDialogBuilder2.setMessage("Tracking will stop \n Do you want to continue?").setCancelable(false).setPositiveButton("YES", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id)
					{
						
						dialog.cancel();

						try
						{
							myTracksService.endCurrentTrack();
							tr = myTracksProviderUtils.getLastTrack();
							
							myTracksProviderUtils.updateTrack(tr);

						
						}
						catch (RemoteException e)
						{
							e.printStackTrace();
						}

						finish();

					}
				}).setNegativeButton("NO", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which)
					{
						dialog.cancel();

					}
				}).show();

			}
		});

		

	}

	@Override
	protected void onStart()
	{
		super.onStart();

		startService(intent);
		bindService(intent, serviceConnection, BIND_AUTO_CREATE);
		dbHelper.openDatabase();
	}

	@Override
	protected void onStop()
	{
		super.onStop();

		// unbind and stop the MyTracks service
		if (myTracksService != null)
		{
			unbindService(serviceConnection);
			System.out.println("unbinding service");
		}
		else
		{
			System.out.println("mytraksService null so not unbinding");
		}
		stopService(intent);
	}

	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
		// exit();
	}

	public void exit()
	{
		// Toast.makeText(MainActivity.this, "exit called", Toast.LENGTH_SHORT).show();
		AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(Layer_Selection_Show.this);
		alertDialogBuilder2.setMessage("Tracking will stop \n Do you want to continue?").setCancelable(false).setPositiveButton("YES", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id)
			{
				
				dialog.cancel();
				if (myTracksService != null)
				{
					try
					{
						if (prabhagNo.length() > 0 && clusterNo.length() > 0)
						{
							// int
							// i=myTracksProviderUtils.getTrack(myTracksProviderUtils.getLastTrack().getId()).getNumberOfPoints();
							if (tr != null)
							{
								myTracksService.endCurrentTrack();
								tr.setName(prabhagNo + "_" + clusterNo);
								myTracksProviderUtils.updateTrack(tr);
							}
						}
						else
						{
							myTracksService.endCurrentTrack();
						}

						
					}
					catch (RemoteException e)
					{
						e.printStackTrace();
					}
				}
				Layer_Selection_Show.this.finish();

			}
		}).setNegativeButton("NO", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which)
			{
				dialog.cancel();
			}
		}).show();
	}

	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		mlocManager.removeUpdates(mlocListener);
		mlocManager.removeUpdates(mnetworklocListener);
		// db.close();
	}
}



