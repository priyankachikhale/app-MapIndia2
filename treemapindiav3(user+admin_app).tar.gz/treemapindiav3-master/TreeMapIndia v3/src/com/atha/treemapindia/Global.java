package com.atha.treemapindia;

public class Global {
	
		/*public static int surveyorId;
		public static int tick;*/
	
}
