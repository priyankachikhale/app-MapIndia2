package com.atha.treemapindia;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.json.JSONArray;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;


public class Showcase_Selection extends Activity{
	
	private static ArrayList<Attribute> attributeList;
	 int serverResponseCode = 0;
	 TextView messageText;
	 ProgressDialog dialog = null;      
	 String upLoadServerUri = null;

	String uploadFilePath;// = "/data/data/com.atha.treemapindia/databases/MapIndia.db";
	 String uploadFileName;
	 static final String FTP_HOST= "10.15.36.57";
     
	    /*********  FTP USERNAME ***********/
	    static final String FTP_USER = "priyanka";
	     
	    /*********  FTP PASSWORD ***********/
	    static final String FTP_PASS  ="priyanka";
	     
	 
	private static ArrayList<Attribute> newattributeList=new ArrayList<Attribute>();
	public static ArrayList<Attribute> getNewattributeList() {
		return newattributeList;
	}

	public static void setNewattributeList(ArrayList<Attribute> newattributeList) {
		Showcase_Selection.newattributeList = newattributeList;
	}

	public static ArrayList<Attribute> getAttributeList() {
		return attributeList;
	}

	public static void setAttributeList(ArrayList<Attribute> attributeList) {
		Showcase_Selection.attributeList = attributeList;
	}

	private List<TextView> alltexts = new ArrayList<TextView>();
	private List<EditText> alledittextsForText = new ArrayList<EditText>();
	private List<EditText> alledittextsForList = new ArrayList<EditText>();
	DBHelper dbhelper;
	Attribute attribute;
	SQLiteDatabase db;
	int listSize;
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.showcase_selection);
		attributeList=Attribute_Selection.getAttributeList();
		messageText  = (TextView)findViewById(R.id.textView1);
		dbhelper=new DBHelper(this);
		
		Iterator<Attribute> it=attributeList.iterator();
		
		while(it.hasNext())
		{
			
			attribute=it.next();
			  TableLayout tl = (TableLayout) findViewById(R.id.showcaseTableLayout);
			  TableRow tr = new TableRow(this);
			  LayoutParams lp = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
			  tr.setLayoutParams(lp);
			  
			  TextView label = new TextView(this);
			  label.setText(attribute.getName());
			  label.setLayoutParams(lp);
			  alltexts.add(label);
			if(attribute.getShowcase().equalsIgnoreCase("Text"))
			{
				
				EditText range=new EditText(this);
				  if(attribute.getType().equalsIgnoreCase("Integer")){
				  
				  range.setText("enter range(e.g.1-9)");
				  
				  }
				  else 
					  range.setText("enter value");
				  alledittextsForText.add(range);
				  tr.addView(label);
				  //tr.addView(showcaseType);
				  tr.addView(range);
				  tl.addView(tr, new TableLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
				  
			}
			
			else if(attribute.getShowcase().equalsIgnoreCase("List"))
			{
				
				  tr.addView(label);
				  String str=attribute.getValue();
				  listSize=Integer.parseInt(attribute.getValue());
				  while(listSize!=0)
				  {
					  EditText listValue=new EditText(this);
					  listValue.setText("enter list value");
					  listValue.setLayoutParams(lp);
					  alledittextsForList.add(listValue);
					  tr.addView(listValue);
					  listSize--;
				  } 
				
				  
				  tl.addView(tr, new TableLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
				  
			}
			
		}
		Button new_object = (Button)findViewById(R.id.new_object);
		new_object.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
            	getValuesInAttribute();
            	saveCurrentObject();
            	
            	Intent mainIntent = new Intent(Showcase_Selection.this, Attribute_Selection.class);
				//mainIntent.putExtra(DatabaseHelper.SURVEYOR_ID[0], 2);
				startActivity(mainIntent);
				Showcase_Selection.this.finish();

            } // end onClick

			
			
        }); // end setOnClickListener
		
		
		Button save_return_to_domain = (Button)findViewById(R.id.save_domain);
		save_return_to_domain.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
            	getValuesInAttribute();
            	saveCurrentObject();
            	
            	/*code to upload
            	 * 
            	 */
            	upLoadServerUri = "http://10.15.36.57/myweb.php";
            	uploadFilePath=DBHelper.getDATABASE_PATH().toString();
            	
            	//uploadFileName="MapIndia.db";
            	uploadFileName=Domain_Selection.getSelectedItem().concat(".db");
            	 dialog = ProgressDialog.show(Showcase_Selection.this, "", "Uploading file...", true);
                 messageText.setText("uploading started.....");
                 /*new Thread(new Runnable() {
                     public void run() {
                                          
                          uploadFile(imagepath);
                                                   
                     }
                   }).start(); */
                 final File f = new File(uploadFilePath);
                 
                 // Upload sdcard file
                 
                 Thread t = new Thread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						uploadFileFTP(f);
						//uploadFile(uploadFilePath);
						
					}

			
				});
               
                 t.start();
            	/*new Thread(new Runnable() {
                    public void run() {
                    	System.out.println("hi");
                         runOnUiThread(new Runnable() {
                                public void run() {
                                    messageText.setText("uploading started.....");
                                }
                            });                    
                       
                         uploadFile(uploadFilePath + "" + uploadFileName);
                                                  
                    }
                  }).start();*/ 
            	//uploadFile(uploadFilePath);
            	
            	/*
            	 * code to change domain
            	 */
            	Intent mainIntent = new Intent(Showcase_Selection.this, Domain_Selection.class);
				//mainIntent.putExtra(DatabaseHelper.SURVEYOR_ID[0], 2);
				startActivity(mainIntent);
				Showcase_Selection.this.finish();

            } // end onClick
        }); // end setOnClickListener

		
	}
	
	private void saveCurrentObject() {
		// TODO Auto-generated method stub
	
		
    	db=dbhelper.openDatabase();
    	//dbHelper.createBaseTables(db);
    	dbhelper.setNEW_TABLE(Attribute_Selection.getObject_Name());
    	
		dbhelper.insertintoMasterTable(Attribute_Selection.getObject_Name(),getNewattributeList() ,db);
		//dbhelper.create_new_table(getAttributeList(),db);
		db.close();
	}
	
	private void getValuesInAttribute() {
		// TODO Auto-generated method stub
		
			Attribute attr;
			Iterator<Attribute> it= attributeList.iterator();
			String cur_showcase;
			String text;
			int listSize;
			StringBuilder temp=new StringBuilder();
			int Text_index=0;
			int List_index=0;
    	//for(int i=0; i < alltexts.size(); i++){
    	    //hashmap.put(allEds.get(i).getText().toString(),"INTEGER");
			while(it.hasNext()){
				attr=it.next();
    		
    		if(attr.getShowcase().equalsIgnoreCase("text"))
    		{
    			text=alledittextsForText.get(Text_index).getText().toString();
    			attr.setRange(text);
    			Text_index++;
    		}
    		else if(attr.getShowcase().equalsIgnoreCase("list"))
    		{
    			listSize=Integer.parseInt(attr.getValue());
    			while(listSize!=0)
    			{
    				if(listSize!=Integer.parseInt(attr.getValue()))
    					temp.append("/");
    				temp.append(alledittextsForList.get(List_index).getText().toString());
    			//it.next().setRange(temp);
    				
    				listSize--;
    				List_index++;
    			}
    			attr.setRange(temp.toString());
    		}
    		
    		newattributeList.add(attr); 		
    		
			}

	}

	
	private void uploadFileFTP(File f) {
		// TODO Auto-generated method stub

		FTPClient ftpClient = new FTPClient();
		String uploadPath="~/temporory/";
		int replyCode;
		boolean status;
		//ftpClient.connect(InetAddress.getByName(server));
		try {
			ftpClient.connect("10.15.36.57", 21);
			replyCode = ftpClient.getReplyCode();
			// now check the reply code, if positive mean connection success
			if (FTPReply.isPositiveCompletion(replyCode)) {
			// login using username & password
			status = ftpClient.login(FTP_USER, FTP_PASS);
			System.out.println(status);
			ftpClient.changeWorkingDirectory(uploadPath);
			ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
			BufferedInputStream buffIn=null;
			buffIn=new BufferedInputStream(new FileInputStream(f));
			ftpClient.enterLocalPassiveMode();
			ftpClient.storeFile(uploadFileName, buffIn);
			buffIn.close();
			ftpClient.logout();
			ftpClient.disconnect();
			}
			else{
				System.out.println("hi");
			}
		} catch (SocketException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	
			
	}
	
	 public int uploadFile(String sourceFileUri) {
         
         
         String fileName = sourceFileUri;
 
         HttpURLConnection conn=null;
         DataOutputStream dos=null;
         String lineEnd = "\r\n";
         String twoHyphens = "--";
         String boundary = "*****";
         int bytesRead, bytesAvailable, bufferSize;
         byte[] buffer;
         int maxBufferSize = 1 * 1024 * 1024;
         File sourceFile = new File(sourceFileUri);
          
         if (!sourceFile.isFile()) {
              
              //dialog.dismiss();
               
              Log.e("uploadFile", "Source File not exist :"
                                  +uploadFilePath);
               
              runOnUiThread(new Runnable() {
                  public void run() {
                      messageText.setText("Source File not exist :"
                              +uploadFilePath);
                  }
              });
               
              return 0;
           
         }
         else
         {
              try {
                   
                    // open a URL connection to the Servlet
                 
                  
                  
                  URL url = new URL(upLoadServerUri);
                  
                  // Open a HTTP  connection to  the URL
                  conn = (HttpURLConnection) url.openConnection();
                  conn.setDoOutput(true);
                  conn.setInstanceFollowRedirects(true);
                  conn.setRequestMethod("POST");
                  conn.setRequestProperty("charset", "UTF-8");
                  conn.setChunkedStreamingMode(0);
            
                  dos = new DataOutputStream(conn.getOutputStream());
                  String name = new File(fileName).getName();
                  
                  dos.writeBytes("filename="+ name + "&data=");
                  //dos.writeBytes("filename=\""+ fileName + "\"" + "&data=");
                   
                  dos.writeBytes(lineEnd);
         
                  FileInputStream fileInputStream = new FileInputStream(sourceFile);
                  
                  // create a buffer of  maximum size
                  bytesAvailable = fileInputStream.available();
         
                  bufferSize = Math.min(bytesAvailable, maxBufferSize);
                  buffer = new byte[bufferSize];
         
                  // read file and write it into form...
                  bytesRead = fileInputStream.read(buffer, 0, bufferSize); 
                     
                  while (bytesRead > 0) {
                       
                    dos.write(buffer, 0, bufferSize);
                    bytesAvailable = fileInputStream.available();
                    bufferSize = Math.min(bytesAvailable, maxBufferSize);
                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);  
                     
                   }


                  // Responses from the server (code and message)
                  serverResponseCode = conn.getResponseCode();
                  String serverResponseMessage = conn.getResponseMessage();
                    
                  Log.i("uploadFile", "HTTP Response is : "
                          + serverResponseMessage + ": " + serverResponseCode);
                   
                  if(serverResponseCode == 200){
                       
                      runOnUiThread(new Runnable() {
                           public void run() {
                                
                               String msg = "File Upload Completed.\n\n" 
                               /*+ " See uploaded file here : \n\n"
                                             +" http://www.androidexample.com/media/uploads/"*/
                                             +uploadFileName;
                                
                               messageText.setText(msg);
                               Toast.makeText(Showcase_Selection.this, "File Upload Complete.",
                                            Toast.LENGTH_SHORT).show();
                           }
                       });               
                  }   
                   
                  //close the streams //
                  fileInputStream.close();
                  dos.flush();
                  dos.close();
                    
             } catch (MalformedURLException ex) {
                  
                 dialog.dismiss(); 
                 ex.printStackTrace();
                  
                 runOnUiThread(new Runnable() {
                     public void run() {
                         messageText.setText("MalformedURLException Exception : check script url.");
                         Toast.makeText(Showcase_Selection.this, "MalformedURLException",
                                                             Toast.LENGTH_SHORT).show();
                     }
                 });
                  
                 Log.e("Upload file to server", "error: " + ex.getMessage(), ex); 
             } catch (Exception e) {
                  
                 dialog.dismiss(); 
                 e.printStackTrace();
                  
                 runOnUiThread(new Runnable() {
                     public void run() {
                         messageText.setText("Got Exception : see logcat ");
                         Toast.makeText(Showcase_Selection.this, "Got Exception : see logcat ",
                                 Toast.LENGTH_SHORT).show();
                     }
                 });
                 Log.e("Upload file to server Exception", "Exception : "
                                                  + e.getMessage(), e); 
             }
             dialog.dismiss();      
             return serverResponseCode;
              
          } // End else block
        }
	 @Override
	 public void onDestroy() {
		    super.onDestroy();
		    if (dialog != null) {
		        dialog.dismiss();
		        dialog = null;
		    }
		}
	 
}
