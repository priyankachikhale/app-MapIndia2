package com.atha.treemapindia;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.SocketException;
import java.text.ParseException;
import java.util.ArrayList;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Activity which displays a login screen to the user.
 */
public class LoginActivity extends Activity
{
	//PRISTART
	String filename;

	ProgressDialog dialog;
	private DBHelper	     dbhelper	         = null;
	SQLiteDatabase db;
	ProgressBar pb;
	String DownloadUrl;
	String server="10.15.36.57";
	int portNumber=21;
    String user="priyanka";
    String password="priyanka";
    String uploadPath="~/temporory/";
    private static int surveyorId;
    Intent mainIntent;
    String uploadFileName;
    String loginValidateServerUri;
    int tick=0;
	public static String domain;
	public static void setDomain(String domain) {
		domain = domain;
	}
	public static String getDomain() {
		return domain;
	}
	
	private ArrayList<String>	 usernames	 = null;

	/**
	 * The default email to populate the email field with.
	 */
	String dwnload_file_path;
    String dest_file_path;
	public static final String	 EXTRA_EMAIL	= "com.example.android.authenticatordemo.extra.EMAIL";

	/**
	 * Keep track of the login task to ensure we can cancel it if requested.
	 */
	private UserLoginTask	     mAuthTask	 = null;

	// Values for email and password at the time of the login attempt.
	private String	             mName;
	private String	             mPassword;
	
	// UI references.
	private AutoCompleteTextView	mEmailView;
	private EditText	         mPasswordView;
	private Button	             signInButton;
	private View	             mLoginFormView;
	private View	             mLoginStatusView;
	private TextView	         mLoginStatusMessageView;
	private String[]	         values;
	private int	                 signInHack	 = 0;
	private static String login;
	int downloadedSize = 0;
    int totalSize = 0;
    File localFile;
    
	public static String getLogin() {
		return login;
	}

	public static void setLogin(String login) {
		LoginActivity.login = login;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		localFile= new File("/data/data/com.atha.treemapindia/databases/login.db");

		setContentView(R.layout.activity_login);

		// Set up the login form.
		mName = getIntent().getStringExtra(EXTRA_EMAIL);
		mEmailView = (AutoCompleteTextView) findViewById(R.id.name);
		mEmailView.setText(mName);

		
		mPasswordView = (EditText) findViewById(R.id.password);
		mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
			@Override
			public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent)
			{
				if (id == EditorInfo.IME_ACTION_DONE)
				{
					try {
						attemptLogin();
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return true;
				}
				return false;
			}
		});
		
		
		/*DBHelper.setDATABASE_NAME("login.db");
		dbhelper= new DBHelper(this);
		db=dbhelper.openDatabase();
		dbhelper.createTables(db);*/
		//db.close();
		//db=dbhelper.openDatabase();
		//usernames = dbhelper.getAllUserNames(db);
		//values = new String[usernames.size()];
		/*for (int i = 0; i < values.length; i++)
		{
			values[i] = usernames.get(i);
		}*/
		
		
		mLoginFormView = findViewById(R.id.login_form);
		mLoginStatusView = findViewById(R.id.login_status);
		mLoginStatusMessageView = (TextView) findViewById(R.id.login_status_message);
		signInButton = (Button) findViewById(R.id.sign_in_button);
		signInButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view)
			{
				try {
					attemptLogin();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				signInHack++;
				if (signInHack >= 3)
				{
					Intent mainIntent = new Intent(LoginActivity.this, Domain_Selection.class);
					startActivity(mainIntent);
					LoginActivity.this.finish();
					signInHack = 0;
					Toast.makeText(LoginActivity.this, "Sign in hack running", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		
		/*DBHelper.setDATABASE_NAME("login.db");
		dbhelper= new DBHelper(this);
		db=dbhelper.openDatabase();
		dbhelper.createTables(db);
		//db.close();
		db=dbhelper.openDatabase();
		//uploadLogin();
		usernames = dbhelper.getAllUserNames(db);
		values = new String[usernames.size()];
		for (int i = 0; i < values.length; i++)
		{
			values[i] = usernames.get(i);
		}*/
		
		//ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_dropdown_item_1line, values);
		mEmailView.setThreshold(1);
		//mEmailView.setAdapter(dataAdapter);

		mEmailView.setOnKeyListener(new OnKeyListener() {

			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event)
			{
				// If the event is a key-down event on the "enter" button
				if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER))
				{
					// Perform action on Enter key press
					mEmailView.clearFocus();
					mPasswordView.requestFocus();
					mPasswordView.setEnabled(true);
					mPasswordView.setText("");
					return true;
				}
				return false;
			}
		});
		mPasswordView.setOnKeyListener(new OnKeyListener() {

			@SuppressLint("NewApi")
			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event)
			{
				// If the event is a key-down event on the "enter" button
				if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER))
				{
					// Perform action on Enter key press
					mPasswordView.clearFocus();
					signInButton.setEnabled(true);
					
					signInButton.callOnClick();
					return true;
				}
				return false;
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		super.onCreateOptionsMenu(menu);
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

	/**
	 * Attempts to sign in to the account specified by the login form. If there are form
	 * errors (invalid email, missing fields, etc.), the errors are presented and no actual login
	 * attempt is made.
	 */
	public void attemptLogin() throws ParseException
	{
		// Reset errors.
		mEmailView.setError(null);
		mPasswordView.setError(null);

		// Store values at the time of the login attempt.
		mName = mEmailView.getText().toString();
		mPassword = mPasswordView.getText().toString();

		boolean cancel = false;
		View focusView = null;

		// Check for a valid password.
		if (TextUtils.isEmpty(mPassword))
		{
			mPasswordView.setError(getString(R.string.error_field_required));
			focusView = mPasswordView;
			cancel = true;
		}
		else if (mPassword.length() < 4)
		{
			mPasswordView.setError(getString(R.string.error_invalid_password));
			focusView = mPasswordView;
			cancel = true;
		}

		// Check for a valid email address.
		if (TextUtils.isEmpty(mName))
		{
			mEmailView.setError(getString(R.string.error_field_required));
			focusView = mEmailView;
			cancel = true;
		}

		if (cancel)
		{
			// There was an error; don't attempt login and focus the first
			// form field with an error.
			focusView.requestFocus();
		}
		else
		{
			// Show a progress spinner, and kick off a background task to
			// perform the user login attempt.
			mLoginStatusMessageView.setText(R.string.login_progress_signing_in);
			tick=0;
			showProgress(true);
			
			if(((mName.equals("admin")) && (mPassword.equals("admin"))))
			{
				DBHelper.setDATABASE_NAME("login.db");
         		dbhelper= new DBHelper(this);
         		db=dbhelper.openDatabase();
         		dbhelper.createTables(db);
			
				Thread t = new Thread(new Runnable() {
					
					@Override
					public void run() {
						uploadLogin();
						surveyorId=-1;
					}

					
			
				});
               
                 t.start();
                
				//
			}
			else{
					 Thread t1 = new Thread(new Runnable() {
						
						@Override
						public void run() {	
						domain=getDomainName();
						
						}
					});
					  t1.start();
					
	                 while(tick!= 2)
	 					;
	                 setDomain(domain);
					
					DBHelper.setDATABASE_NAME(getDomain()+".db");
					localFile= new File("/data/data/com.atha.treemapindia/databases/"+getDomain()+".db");		
					
					Thread t = new Thread(new Runnable() {
						
						@Override
						public void run() {
			
						try {
							downloadAndSaveFile();
							surveyorId=1;	
							tick=1;
						
						} catch (IOException e) {
							System.out.println("exception while download and save");
						}
				
						}
					});
	               
	                 t.start();
	                 
			
				}
			
			mAuthTask = new UserLoginTask(this);
			System.out.println("hi here");
			mAuthTask.execute((Void) null);
			System.out.println("hey there");
			
		}
	}

	/**
	 * Shows the progress UI and hides the login form.
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
	private void showProgress(final boolean show)
	{
		// On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
		// for very easy animations. If available, use these APIs to fade-in
		// the progress spinner.
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2)
		{
			int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

			mLoginStatusView.setVisibility(View.VISIBLE);
			mLoginStatusView.animate().setDuration(shortAnimTime).alpha(show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
				@Override
				public void onAnimationEnd(Animator animation)
				{
					mLoginStatusView.setVisibility(show ? View.VISIBLE : View.GONE);
				}
			});

			mLoginFormView.setVisibility(View.VISIBLE);
			mLoginFormView.animate().setDuration(shortAnimTime).alpha(show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
				@Override
				public void onAnimationEnd(Animator animation)
				{
					mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
				}
			});
		}
		else
		{
			// The ViewPropertyAnimator APIs are not available, so simply show
			// and hide the relevant UI components.
			mLoginStatusView.setVisibility(show ? View.VISIBLE : View.GONE);
			mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
		}
		
		
	}

	/**
	 * Represents an asynchronous login/registration task used to authenticate the user.
	 */
	public class UserLoginTask extends AsyncTask<Void, Void, Boolean>
	{
		LoginActivity	la	= null;
		//int		      surveyorId;

		public UserLoginTask(LoginActivity la)
		{
			super();
			this.la = la;
		}

		@Override
		protected Boolean doInBackground(Void... params)
		{ 
			
			//if (dbhelper.openDatabase()!=null)
			//{
				Log.i("login", "auth: " + surveyorId);
				
				//DBHelper.setDATABASE_NAME(filename.toString());
				setLogin(mName);
				while(tick !=1)
					;
			
				if (surveyorId > 0)
				{
					File dbFile = new File("/data/data/com.atha.treemapindia/databases/login.db");
				    
				     File dbFile1 = new File("/data/data/com.atha.treemapindia/databases/School.db");
				    
					Intent mainIntent = new Intent(LoginActivity.this, Layer_Selection_Show.class);				
				    // Intent mainIntent = new Intent(LoginActivity.this, Domain_Selection.class);
					startActivity(mainIntent);
					LoginActivity.this.finish();
				}
				else if(surveyorId == -1)
				{
					dbhelper.close();
					
					    
					mainIntent = new Intent(LoginActivity.this, Domain_Selection.class);
					startActivity(mainIntent);
					LoginActivity.this.finish();
					
				}
				
				
				else 
				{
					runOnUiThread(new Runnable() {
						public void run()
						{
							mPasswordView.setError("Incorrect Password");
						}
					});
				}
			
			return true;
		}

		@Override
		protected void onPostExecute(final Boolean success)
		{
			mAuthTask = null;
			showProgress(false);
			

		}

		@Override
		protected void onCancelled()
		{
			mAuthTask = null;
			showProgress(false);
			startActivity(mainIntent);
			LoginActivity.this.finish();
		}
	}
		   void uploadLogin(){
		   final File f ;
			String st;
			String uploadFilePath=DBHelper.getDATABASE_PATH().toString();

			try{
				
				st=uploadFilePath;
				f= new File(uploadFilePath);
				uploadFileFTP(f);
				tick=1;
			}
			catch(Exception e){
				e.printStackTrace();
			}
				   }

	   
	   private void uploadFileFTP(File f) {
			// TODO Auto-generated method stub

			FTPClient ftpClient = new FTPClient();
			
			int replyCode;
			uploadFileName="login.db";
			boolean status;
			//ftpClient.connect(InetAddress.getByName(server));
			try {
				ftpClient.connect(server, portNumber);
				replyCode = ftpClient.getReplyCode();
				// now check the reply code, if positive mean connection success
				if (FTPReply.isPositiveCompletion(replyCode)) {
				// login using username & password
				status = ftpClient.login(user,password);
				System.out.println(status);
				ftpClient.changeWorkingDirectory(uploadPath);
				ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
				BufferedInputStream buffIn=null;
				buffIn=new BufferedInputStream(new FileInputStream(f));
				ftpClient.enterLocalPassiveMode();
				ftpClient.storeFile(uploadFileName, buffIn);
				buffIn.close();
				ftpClient.logout();
				ftpClient.disconnect();
				
				}
				else{
				
				}
			} catch (SocketException e) {
				
				e.printStackTrace();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
		
				
		}
	   
	   private Boolean downloadAndSaveFile()
		        throws IOException {
		    FTPClient ftp = null;
		    
		    		filename="temporory/"+domain+".db";
		    try {
		        ftp = new FTPClient();
		        ftp.connect(server, portNumber);
		        ftp.login(user, password);
		        ftp.setFileType(FTP.BINARY_FILE_TYPE);
		        ftp.enterLocalPassiveMode();
		        int file_size = Integer.parseInt(String.valueOf(filename.length()));
			       System.out.println(file_size);
			       System.out.println("hey");
		        OutputStream outputStream = null;
		        boolean success = false;
		        try {
		            outputStream = new BufferedOutputStream(new FileOutputStream(
		                    localFile));
		            success = ftp.retrieveFile(filename, outputStream);
		        } finally {
		            if (outputStream != null) {
		                outputStream.close();
		            }
		        }
		        file_size = Integer.parseInt(String.valueOf(localFile.length()));
			       System.out.println(file_size);
			       System.out.println("hey");
		        return success;
		    } finally {
		        if (ftp != null) {
		            ftp.logout();
		            ftp.disconnect();
		        }
		    }
		}
	   
	   
	   private String getDomainName()
	   {
		   String result=null;
			InputStream is = null;
			StringBuilder sb = null;
			ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();		
			nameValuePairs.add(new BasicNameValuePair("username",mName));
			nameValuePairs.add(new BasicNameValuePair("password",mPassword));
		   try {
				
				HttpClient httpclient = new DefaultHttpClient();
				HttpPost httppost = new HttpPost("http://10.15.36.57/login2.php");
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				HttpEntity entity = response.getEntity();
				is = entity.getContent();
			} catch (Exception e) {
				Log.e("log_tag", "Error in http connection" + e.toString());
			}
			// convert response to string
			try {
				BufferedReader reader = new BufferedReader(new InputStreamReader(
						is, "iso-8859-1"), 8);
				sb = new StringBuilder();
				sb.append(reader.readLine());
				String line;
				while ((line = reader.readLine()) != null) {
					sb.append(line);
				}
				is.close();
				result = sb.toString();
			} catch (Exception e) {
				Log.e("log_tag", "Error converting result " + e.toString());
			}
			// paring data
			tick=2;
			return result;
	   }
	   
	  

}